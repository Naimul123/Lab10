package edu.temple.lab10;


interface OnSymbolSelectedListener {

    void setStockInfo(String stock);
}
